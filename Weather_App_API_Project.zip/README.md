# 🌦 Weather App (API Project)

A responsive **Weather Application** that fetches real-time weather data using the **OpenWeatherMap API**.

## 🚀 Features
- Search weather by city name
- Real-time temperature, humidity, wind speed
- Clean and responsive UI
- API integration using JavaScript Fetch API

## 🛠 Tech Stack
- HTML
- CSS
- JavaScript
- OpenWeatherMap API

## 🔧 Setup
1. Get a free API key from https://openweathermap.org/
2. Replace `YOUR_API_KEY_HERE` in `script.js`
3. Open `index.html` in a browser

## 👤 Author
Shivaprasad Chinthoju
